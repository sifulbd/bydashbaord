// import { createContext, useState } from "react";

// const ThemeContext = createContext("color");

// export default ThemeContext;
